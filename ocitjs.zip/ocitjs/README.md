# selfJS
Selfbot + 1 js
 # SELFBOT + JS

 # HANYA UJI COBA SAJA 

 # SYUKUR SYUKUR KALAU WORK :D

 

# INSTALL DI VPS :

    sudo apt-get update -y

    sudo apt-get install git -y

    sudo apt-get install python3-pip -y

    sudo pip3 install rsa

    sudo pip3 install thrift==0.11.0

    sudo pip3 install requests

    sudo pip3 install pytz

    sudo pip3 install bs4

    sudo pip3 install gtts

    sudo pip3 install googletrans

    sudo pip3 install humanize

    sudo pip3 install humanfriendly

    sudo pip3 install beautifulsoup

    sudo pip3 install pytz

    sudo pip3 install ffmpy

    sudo pip3 install goslate

    sudo pip3 install pafy

    sudo pip3 install wikipedia

    sudo pip3 install tweepy

    sudo pip3 install youtube_dl

    git clone https://github.com/fajarprasetiya/selfJS

    cd selfJS

    python3 selfJS.py

# INSTALL Di TERMUX :

    apt update && apt upgrade

    pkg install git

    pkg install python3

    pip3 install rsa

    pip3 install thrift==0.11.0

    pip3 install requests

    pip3 install bs4

    pip3 install gtts

    pip3 install beautifulsoup

    pip3 install googletrans

    pip3 install pafy

    pip3 install humanize

    pip3 install humanfriendly

    pip3 install pytz

    pip3 install ffmpy

    pip3 install goslate

    pip3 install wikipedia

    pip3 install youtube_dl

    pip3 install tweepy

    git clone https://github.com/fajarprasetiya/selfJS

    cd KAGAME

    python3 selfJS.py

 

# id line : prast_hunter17

  

 # thanks buat para mastah yg sudah membuat sc tersebut

 # gue hanya bantu share & modifikasi ulang saja
